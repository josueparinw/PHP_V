<h1>=== Catálogo ===</h1>

<h2>Todas las películas</h2>
<section class="pelis-total">
    <?php foreach ($peliculas as $pelicula): ?>
        <div class="item">
            <?php pintarTarjeta($pelicula); ?>
        </div>
    <?php
    endforeach;
    ?>
</section>


<hr>
<h2>Películas de Comedia</h2>
<section class="pelis-comedia">
    <?php foreach ($peliculas as $pelicula):
        if ($pelicula["genero"]==="Comedia"):
    ?>

        <div class="item">
            <?php pintarTarjeta($pelicula); ?>
        </div>

    <?php
        endif;
    endforeach;
    ?>
</section>  