<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<!--
Sin sesión:  Inicio | Catalogo | Login
Con sesión:  Inicio | Catalogo | Dashboard | Logout
ADMIN:       Inicio | Catalogo | Dashboard | Añadir item | Logout
-->
    <nav>
        <a href="../index.php">Inicio</a>
        <a href="../catalogo.php">Catalogo</a>
        <a href="../dashboard.php">Dashboard</a>
        <a href="../controllers/logout.php">Logout</a>
        <a href="../add_item.php">Añadir item</a>
    </nav>
</body>
</html>